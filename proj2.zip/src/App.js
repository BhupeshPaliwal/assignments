import "./App.css";
import React from "react";
import ShowForm from './components/button';
import Gauge  from "./components/gauge";


function App() {
  return (
    <div>
      <Gauge/>
    </div>
  );
}

export default App;
